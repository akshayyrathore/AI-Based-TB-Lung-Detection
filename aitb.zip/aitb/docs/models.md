# Pretrained Models

## TB-Net Chest X-Ray Classification
|  Type | Input Resolution | TB Sensitivity | Accuracy | # Params (M) | MACs (G) |        Model        |
|:-----:|:----------------:|:--------------:|:--------:|:------------:|:---------:|:-------------------:|
|  ckpt |      224x224     |      100.0     |   99.86  |     4.24     |   0.42    |[TB-Net](https://drive.google.com/drive/folders/1l2JSOcoeSJip7dtLpnOoWvpM9-KEHb1b?usp=sharing)|
